import { Component } from '@angular/core';

@Component({
  selector: 'app-layoutauth',
  templateUrl: './layoutauth.component.html',
  styleUrls: ['./layoutauth.component.css']
})
export class LayoutauthComponent {

}
