import { Component } from '@angular/core';

@Component({
  selector: 'app-layoutblank',
  templateUrl: './layoutblank.component.html',
  styleUrls: ['./layoutblank.component.css'],
})
export class LayoutblankComponent {}
