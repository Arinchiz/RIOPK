import { ViewportScroller } from '@angular/common';
import { Component } from '@angular/core';
import { DashboardService } from 'src/app/core/dashboard.service';
import { Allorders } from 'src/app/interfaces/allorders';

@Component({
  selector: 'app-dash-board-data',
  templateUrl: './dash-board-data.component.html',
  styleUrls: ['./dash-board-data.component.css'],
})
export class DashBoardDataComponent {
  constructor(
    private _dashboardService: DashboardService,
    private _viewportScroller: ViewportScroller
  ) {}
  inputSearch: string = '';
  pageSize: number = 10;
  currentPage: number = 0;
  totalItems: number = 0;
  totalPrice: number = 0;
  couterPrice: number = 0;
  couterOrders: number = 0;
  totaOrders: number = 0;
  ngOnInit(): void {
    this.getAllOrders();
    this.counterPrice();
    this.counterProducts();
  }

  allOrders = [
    {
      id: 'ORD-001',
      createdAt: new Date('2024-01-15'),
      user: {
        name: 'Иван Петров',
        email: 'ivan@mail.ru'
      },
      totalOrderPrice: 8450,
      status: 'completed',
      paymentMethodType: 'card',
      isPaid: true,
      isDelivered: true
    },
    {
      id: 'ORD-002',
      createdAt: new Date('2024-01-14'),
      user: {
        name: 'Мария Сидорова',
        email: 'maria@mail.ru'
      },
      totalOrderPrice: 3240,
      status: 'processing',
      paymentMethodType: 'cash',
      isPaid: false,
      isDelivered: false
    },
    {
      id: 'ORD-003',
      createdAt: new Date('2024-01-14'),
      user: {
        name: 'Алексей Козлов',
        email: 'alex@mail.ru'
      },
      totalOrderPrice: 15670,
      status: 'shipped',
      paymentMethodType: 'card',
      isPaid: true,
      isDelivered: false
    },
    {
      id: 'ORD-004',
      createdAt: new Date('2024-01-13'),
      user: {
        name: 'Елена Новикова',
        email: 'elena@mail.ru'
      },
      totalOrderPrice: 5430,
      status: 'pending',
      paymentMethodType: 'card',
      isPaid: true,
      isDelivered: false
    },
    {
      id: 'ORD-005',
      createdAt: new Date('2024-01-13'),
      user: {
        name: 'Дмитрий Волков',
        email: 'dmitry@mail.ru'
      },
      totalOrderPrice: 8920,
      status: 'cancelled',
      paymentMethodType: 'cash',
      isPaid: false,
      isDelivered: false
    }
  ];

  getStatusClass(status: string): string {
    const statusClasses: {[key: string]: string} = {
      'pending': 'bg-warning',
      'processing': 'bg-info',
      'shipped': 'bg-primary',
      'completed': 'bg-success',
      'cancelled': 'bg-danger'
    };
    return statusClasses[status] || 'bg-secondary';
  }

  getStatusText(status: string): string {
    const statusTexts: {[key: string]: string} = {
      'pending': 'Ожидание',
      'processing': 'В обработке',
      'shipped': 'Отправлен',
      'completed': 'Выполнен',
      'cancelled': 'Отменен'
    };
    return statusTexts[status] || 'Неизвестно';
  }

  getPaymentIcon(paymentType: string): string {
    const paymentIcons: {[key: string]: string} = {
      'card': 'fa-brands fa-cc-visa text-primary',
      'cash': 'fa-solid fa-wallet text-success'
    };
    return paymentIcons[paymentType] || 'fa-solid fa-money-bill';
  }

  getPaymentText(paymentType: string): string {
    const paymentTexts: {[key: string]: string} = {
      'card': 'Карта',
      'cash': 'Наличные'
    };
    return paymentTexts[paymentType] || 'Другое';
  }

  //^ shared Main Functions
  getTotalPrice(response: Allorders[]): void {
    response.map((item) => {
      this.couterPrice += item.totalOrderPrice;
    });
  }
  counterPrice() {
    let count = 0;
    setInterval(() => {
      if (this.totalPrice <= this.couterPrice) {
        this.totalPrice += count++;
      } else {
        return;
      }
    }, 10);
  }
  counterProducts() {
    let count = 0;
    setInterval(() => {
      if (this.couterOrders <= this.totaOrders) {
        this.couterOrders += count++;
      } else {
        return;
      }
    }, 10);
  }
  pageChanged(event: any) {
    this._dashboardService.allOrders(event).subscribe({
      next: (response) => {
        this.allOrders = response.data;
        this.pageSize = response.metadata.limit;
        this.currentPage = response.metadata.currentPage;
        this.totalItems = response.results;
        this._viewportScroller.scrollToPosition([0, 0]);
        //* all Users Paginations
      },
    });
  }
  getAllOrders() {
    this._dashboardService.allOrders().subscribe({
      next: (response) => {
        this.totaOrders = response.results;
        this.allOrders = response.data;
        this.getTotalPrice(response.data);
      },
    });
  }
}
