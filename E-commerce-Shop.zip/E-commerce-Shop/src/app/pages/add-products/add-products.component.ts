import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";

@Component({
  selector: 'app-add-products',
  templateUrl: './add-products.component.html',
  styleUrls: ['./add-products.component.css'],
})
export class AddProductsComponent implements OnInit {
  productForm: FormGroup;
  previewImage: string | null = null;
  imageCover: File | null = null;
  imageCoverValid: boolean = false;
  isLoding: boolean = false;

  constructor(private fb: FormBuilder) {
    this.productForm = this.fb.group({
      title: ['', [Validators.required, Validators.minLength(3)]],
      category: ['', Validators.required],
      brand: ['', Validators.required],
      price: ['', [Validators.required, Validators.min(1)]],
      description: ['', [Validators.required, Validators.minLength(10)]],
      quantity: ['', [Validators.required, Validators.min(0)]],
      offer: [0, [Validators.min(0), Validators.max(100)]],
      ratingsAverage: [4.5, [Validators.min(0), Validators.max(5)]]
    });
  }

  ngOnInit() {
  }

  // Геттеры для удобного доступа к контролам
  get title() { return this.productForm.get('title'); }
  get category() { return this.productForm.get('category'); }
  get brand() { return this.productForm.get('brand'); }
  get price() { return this.productForm.get('price'); }
  get description() { return this.productForm.get('description'); }
  get quantity() { return this.productForm.get('quantity'); }
  get offer() { return this.productForm.get('offer'); }
  get ratingsAverage() { return this.productForm.get('ratingsAverage'); }

  onImageCoverChange(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.imageCover = file;
      this.imageCoverValid = file.type.startsWith('image/');

      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.previewImage = e.target.result;
      };
      reader.readAsDataURL(file);
    }
  }

  onImagesChange(event: any): void {
    const files = event.target.files;
    console.log('Дополнительные изображения:', files);
  }

  onSubmit(): void {
    if (this.productForm.valid && this.imageCover) {
      this.isLoding = true;

      const formData = this.productForm.value;
      console.log('Данные формы:', formData);

      // Имитация API запроса
      setTimeout(() => {
        this.isLoding = false;
        alert('Товар успешно добавлен!');
        this.resetForm();
      }, 2000);
    } else {
      this.markFormGroupTouched();
      if (!this.imageCover) {
        alert('Пожалуйста, загрузите основное изображение товара');
      }
    }
  }

  resetForm(): void {
    this.productForm.reset({
      offer: 0,
      ratingsAverage: 4.5,
      quantity: 0
    });
    this.previewImage = null;
    this.imageCover = null;
    this.imageCoverValid = false;
  }

  private markFormGroupTouched(): void {
    Object.keys(this.productForm.controls).forEach(key => {
      this.productForm.get(key)?.markAsTouched();
    });
  }
}
