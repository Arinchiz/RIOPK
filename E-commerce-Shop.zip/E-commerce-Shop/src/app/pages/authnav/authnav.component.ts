import { Component } from '@angular/core';

@Component({
  selector: 'app-authnav',
  templateUrl: './authnav.component.html',
  styleUrls: ['./authnav.component.css'],
})
export class AuthnavComponent {
}
