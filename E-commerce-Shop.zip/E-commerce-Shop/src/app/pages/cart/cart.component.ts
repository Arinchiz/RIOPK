import { CartService } from 'src/app/core/cart.service';
import { AfterViewInit, Component, OnInit } from '@angular/core';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { BtncartComponent } from 'src/app/shared/btncart/btncart.component';
import { NotifierService } from 'angular-notifier';
import { toggleFade } from 'src/app/shared/animations/toggle-fade';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
  animations: [toggleFade],
})
export class CartComponent implements AfterViewInit {
  constructor(
    private _cartService: CartService,
    private _notifierService: NotifierService
  ) {}
  cartProduct: any;
  isLoding: boolean = false;
  ngAfterViewInit(): void {
    // this.displayCartUser();
    this.cartProduct = {
      status: 'success',
      numOfCartItems: 1,
      data: {
        _id: 'cart123456',
        cartOwner: 'user123',
        totalCartPrice: 299,
        createdAt: '2024-02-15T10:00:00.000Z',
        updatedAt: '2024-02-15T10:30:00.000Z',
        products: [
          {
            count: 1,
            _id: 'cartItem789',
            product: {
              _id: '7',
              id: '7',
              title: 'Детский шезлонг-качалка 4moms MamaRoo',
              slug: '4moms-mamaroo-baby-swing',
              description: 'Инновационный детский шезлонг с 5 уникальными движениями качания, встроенными звуками природы, Bluetooth подключением и регулируемым наклоном. Имитирует естественные движения родителей.',
              quantity: 8,
              price: 349,
              priceAfterDiscount: 299,
              imageCover: 'assets/images/products/шезлонг.jpg',
              offer: 14,
              ratingsAverage: 4.9,
              ratingsQuantity: 156,
              sold: 34,
              createdAt: '2024-01-25T09:30:00.000Z',
              updatedAt: '2024-02-01T15:20:00.000Z',
              category: {
                _id: 'cat7',
                name: 'Развлечения и развитие',
                slug: 'entertainment-development',
                image: 'assets/images/categories/entertainment.jpg'
              },
              brand: {
                _id: 'brand7',
                name: '4moms',
                slug: '4moms',
                image: 'assets/images/brands/4moms.jpg'
              },
              subcategory: [
                {
                  _id: 'sub7',
                  name: 'Шезлонги и качели',
                  slug: 'bouncers-swings',
                  category: 'cat7'
                },
                {
                  _id: 'sub8',
                  name: 'Электронные игрушки',
                  slug: 'electronic-toys',
                  category: 'cat7'
                }
              ],
              images: [
                'assets/images/products/baby-swing-4moms-1.jpg',
                'assets/images/products/baby-swing-4moms-2.jpg',
                'assets/images/products/baby-swing-4moms-3.jpg',
                'assets/images/products/baby-swing-4moms-4.jpg'
              ]
            },
            price: 299
          }
        ]
      }
    };
  }

  displayCartUser(): void {
    this._cartService.getCartUser().subscribe({
      next: (respons) => {
        this.cartProduct = respons;
        this._cartService.cartNumber.next(this.cartProduct.numOfCartItems);
      },
      error: (erorr) => {
        console.log(erorr);
      },
    });
  }

  removeCartItem(id: string, Btn: BtncartComponent) {
    Btn.isLoding = true;
    this._cartService.removeCartItem(id).subscribe({
      next: (respons) => {
        Btn.isLoding = false;
        this.cartProduct = respons;
        this._cartService.cartNumber.next(respons.numOfCartItems);
        this._notifierService.notify('error', 'Item removed from the cart');
      },
      error: (erorr) => {
        console.log(erorr);

        Btn.isLoding = false;
      },
    });
  }
  updateCountItem(id: string, countItem: number, status: string, msg: string) {
    if (countItem > 0) {
      this._cartService.updateCartQuantity(id, countItem).subscribe({
        next: (respons) => {
          this.cartProduct = respons;
          this._cartService.cartNumber.next(respons.numOfCartItems);
          this._notifierService.notify(`${status}`, `${msg}`);
        },
        error: (erorr) => {
          console.log(erorr);
        },
      });
    }
  }
  removeAllItem() {
    this._cartService.clearCart().subscribe({
      next: (respons) => {
        if (respons.message === 'success') {
          this.cartProduct = null;
          this._cartService.cartNumber.next(0);
        }
      },
      error: (erorr) => {
        console.log(erorr);
      },
    });
  }
  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(
      this.cartProduct.data.products,
      event.previousIndex,
      event.currentIndex
    );
  }
}
