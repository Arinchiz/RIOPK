import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { CartService } from 'src/app/core/cart.service';
import { ProductsDataService } from 'src/app/core/products-data.service';
import { Products } from 'src/app/interfaces/products';
import {
  cartSlideLeft,
  cartSlideRight,
  slidUp,
} from 'src/app/shared/animations/toggle-fade';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css'],
  animations: [cartSlideLeft, cartSlideRight, slidUp],
})
export class DetailsComponent implements OnInit {
  constructor(
    private _productsDataService: ProductsDataService,
    private _activatedRoute: ActivatedRoute,
    private _cartService: CartService,
    private _notifierService: NotifierService,
    private _router: Router
  ) {}
  productDetails: Products = {} as Products;
  selectedImage: string = '';
  activeImage: string = 'assets/images/products/шезлонг.jpg';
  animationState: string = 'start';
  idProduct: string = '';
  offer: number = 299;
  isLoding: boolean = false;

  @ViewChild('allIMages') sliderImages!: ElementRef;

  ngOnInit(): void {
    // this._activatedRoute.data.subscribe({
    //   next: (params: any) => {
    //     this.productDetails = params.mydetails.data;
    //     const lastIndex = this.productDetails.images[0];
    //     this.activeImage = lastIndex;
    //     this.getDinamicCols();
    //     this.getOffer(this.productDetails);
    //   },
    // });
    this.productDetails = {
        "sold": 156,
          "images": [
          "https://ecommerce.routemisr.com/Route-Academy-products/1680394855240-2.jpeg",
          "https://ecommerce.routemisr.com/Route-Academy-products/1680394855240-3.jpeg",
          "https://ecommerce.routemisr.com/Route-Academy-products/1680394855239-1.jpeg",
          "https://ecommerce.routemisr.com/Route-Academy-products/1680394855240-4.jpeg"
        ],
          "subcategory": [
          {
            "_id": "6407f243b575d3b90bf957ac",
            "name": "Детские шезлонги",
            "slug": "baby-bouncers",
            "category": "6439d5b90049ad0b52b90048"
          },
          {
            "_id": "6407f243b575d3b90bf957ad",
            "name": "Электронные игрушки",
            "slug": "electronic-toys",
            "category": "6439d5b90049ad0b52b90048"
          }
        ],
          "ratingsQuantity": 89,
          "_id": "6428ca68dc1175abc65ca07b",
          "title": "Детский шезлонг-качалка 4moms MamaRoo",
          "slug": "4moms-mamaroo-baby-swing",
          "description": "Материал: Пластик, Ткань\nЦвет: Серый\nВес: 8.5 кг\nМаксимальный вес: 11 кг\nВозраст: 0-9 месяцев\nОсобенности: 5 режимов качания, Bluetooth, встроенные звуки, ночник",
          "quantity": 15,
          "price": 349,
          "imageCover": "https://ecommerce.routemisr.com/Route-Academy-products/1680394855158-cover.jpeg",
          "category": {
          "_id": "6439d5b90049ad0b52b90048",
            "name": "Детские товары",
            "slug": "baby-products",
            "image": "https://ecommerce.routemisr.com/Route-Academy-categories/1681511865180.jpeg"
        },
        "brand": {
          "_id": "64089c3924b25627a2531593",
            "name": "4moms",
            "slug": "4moms",
            "image": "https://ecommerce.routemisr.com/Route-Academy-brands/1678285881943.png"
        },
        "ratingsAverage": 4.9,
          "createdAt": "2025-10-15T10:20:56.323Z",
          "updatedAt": "2025-10-18T13:52:49.291Z",

          "id": "6428ca68dc1175abc65ca07b",
      "priceAfterDiscount": 1231,
      "offer": 123
      }
  }
  selectImage(image: string): void {
    this.selectedImage = image;
    this.activeImage = image;
  }
  isActive(image: string): boolean {
    return this.selectedImage === image;
  }

  getDinamicCols(): string {
    const cols: number = 12;
    let arrayLength = cols / this.productDetails.images.length;
    if (arrayLength < 3) {
      arrayLength = 3;
    }
    return `col-${arrayLength}`;
  }

  addProduct(id: string): void {
    this.isLoding = true;
    this._cartService.addToCart(id).subscribe({
      next: (respons) => {
        this._cartService.cartNumber.next(respons.numOfCartItems);
        this._notifierService.notify('success', respons.message);
        this.isLoding = false;
      },
      error: (err) => {
        this.isLoding = false;
      },
    });
  }

  toggleAnimationState() {
    this.animationState = this.animationState === 'start' ? 'end' : 'start';
  }

  getOffer(detalsProduct: Products) {
    if (!detalsProduct.priceAfterDiscount) {
      this.offer = Math.trunc(detalsProduct.price * 0.9);
    } else {
      this.offer = detalsProduct.priceAfterDiscount;
    }
  }

  next() {
    this._productsDataService.allProducts().subscribe({
      next: (arr) => {
        let startFromLength = arr.data.findIndex(
          (obj: Products) => obj.id === this.idProduct
        );

        if (startFromLength >= 39) {
          /* minus one to will i incress it with 1 */
          startFromLength = -1;
        }
        console.log(startFromLength);
        /* get the init id when i open details padge */
        let nextId = arr.data[startFromLength + 1].id;

        this._router.navigate(['/details', nextId]);
        /* update idProduct with the prev id */
        this.idProduct = nextId;
      },
    });
  }
  prev() {
    this._productsDataService.allProducts().subscribe({
      next: (arr) => {
        let startFromLength = arr.data.findIndex(
          (obj: Products) => obj.id === this.idProduct
        );
        if (startFromLength <= 0) {
          /* minus one to will i incress it with 1 */
          startFromLength = arr.data.length - 1;
        }
        /* get the init id when i open details padge */
        let nextId = arr.data[startFromLength - 1].id;

        this._router.navigate(['/details', nextId]);
        // /* update idProduct with the prev id */
        this.idProduct = nextId;
      },
    });
  }
}
