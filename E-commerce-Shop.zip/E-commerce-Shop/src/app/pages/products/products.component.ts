import { ViewportScroller } from '@angular/common';
import {
  Component,
  ElementRef,
  OnInit,
  Renderer2,
  ViewChild,
} from '@angular/core';
import { ProductsDataService } from 'src/app/core/products-data.service';
import { Products } from 'src/app/interfaces/products';
import { feadToggle } from 'src/app/shared/animations/toggle-fade';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
  animations: [feadToggle],
})
export class ProductsComponent implements OnInit {
  constructor(
    private _productsDataService: ProductsDataService,
    private _renderer2: Renderer2,
    private viewportScroller: ViewportScroller
  ) {}
  @ViewChild('categories') chosesCategory!: ElementRef;
  @ViewChild('stars') allStarts!: ElementRef;

  allProducts: Products[] = [];
  selectedBrandName: string = '';
  selectedCategoryName: any = '';
  uniqeBrands: string[] = [''];
  inputSearch: string = '';
  pageSize: number = 10;
  currentPage: number = 0;
  totalItems: number = 0;
  isLoding: boolean = false;
  selectedOption: string = 'all';
  sortBy: string = 'sort';
  ratingNumber: number = 5;
  isClassApplied: boolean = false;
  priceRange: number = 45000;
  productLength: number = 0;

  ngOnInit(): void {
    // this.displayAllProducts();
    this.allProducts = [
      {
        _id: '1',
        id: '1',
        title: 'Умная детская коляска 3 в 1 Stokke',
        slug: 'stokke-smart-stroller-3in1',
        description: 'Премиальная коляска-трансформер с системой амортизации, регулируемой ручкой и съемной люлькой. Подходит от рождения до 3 лет.',
        quantity: 15,
        price: 45900,
        priceAfterDiscount: 38900,
        imageCover: 'assets/images/products/stroller-stokke.jpg',
        offer: 15,
        ratingsAverage: 4.9,
        ratingsQuantity: 127,
        sold: 89,
        createdAt: '2024-01-15T10:00:00.000Z',
        updatedAt: '2024-01-20T14:30:00.000Z',
        category: {
          _id: 'cat1',
          name: 'Коляски и переноски',
          slug: 'strollers-carriers',
          image: 'assets/images/categories/strollers.jpg'
        },
        brand: {
          _id: 'brand1',
          name: 'Stokke',
          slug: 'stokke',
          image: 'assets/images/brands/stokke.jpg'
        },
        subcategory: [
          {
            _id: 'sub1',
            name: 'Коляски 3 в 1',
            slug: '3in1-strollers',
            category: 'cat1'
          }
        ],
        images: [
          'assets/images/products/stroller-stokke-1.jpg',
          'assets/images/products/stroller-stokke-2.jpg',
          'assets/images/products/stroller-stokke-3.jpg'
        ]
      },
      {
        _id: '2',
        id: '2',
        title: 'Автокресло Cybex Cloud Z i-Size',
        slug: 'cybex-cloud-z-isize',
        description: 'Безопасное автокресло группы 0+ с поворотной системой, защитой от боковых ударов и регулируемым подголовником.',
        quantity: 25,
        price: 150,
        priceAfterDiscount: 24500,
        imageCover: 'assets/images/products/автокресло.jpg',
        offer: 12,
        ratingsAverage: 4.8,
        ratingsQuantity: 94,
        sold: 67,
        createdAt: '2024-01-10T09:00:00.000Z',
        updatedAt: '2024-01-18T16:45:00.000Z',
        category: {
          _id: 'cat2',
          name: 'Автокресла',
          slug: 'car-seats',
          image: 'assets/images/categories/car-seats.jpg'
        },
        brand: {
          _id: 'brand2',
          name: 'Cybex',
          slug: 'cybex',
          image: 'assets/images/brands/cybex.jpg'
        },
        subcategory: [
          {
            _id: 'sub2',
            name: 'Автокресла 0+',
            slug: '0plus-car-seats',
            category: 'cat2'
          }
        ],
        images: [
          'assets/images/products/car-seat-cybex-1.jpg',
          'assets/images/products/car-seat-cybex-2.jpg',
          'assets/images/products/car-seat-cybex-3.jpg'
        ]
      },
      {
        _id: '3',
        id: '3',
        title: 'Подгузники Huggies Elite Soft',
        slug: 'huggies-elite-soft-diapers',
        description: 'Супермягкие подгузники с экстра защитой на 12 часов, индикатором влаги и анатомической формой. Размер 4 (9-14 кг).',
        quantity: 200,
        price: 50,
        priceAfterDiscount: 1590,
        imageCover: 'assets/images/products/подгузники.jpg',
        offer: 16,
        ratingsAverage: 4.7,
        ratingsQuantity: 356,
        sold: 1240,
        createdAt: '2024-01-05T08:00:00.000Z',
        updatedAt: '2024-01-22T11:20:00.000Z',
        category: {
          _id: 'cat3',
          name: 'Гигиена и уход',
          slug: 'hygiene-care',
          image: 'assets/images/categories/hygiene.jpg'
        },
        brand: {
          _id: 'brand3',
          name: 'Huggies',
          slug: 'huggies',
          image: 'assets/images/brands/huggies.jpg'
        },
        subcategory: [
          {
            _id: 'sub3',
            name: 'Подгузники',
            slug: 'diapers',
            category: 'cat3'
          }
        ],
        images: [
          'assets/images/products/diapers-huggies-1.jpg',
          'assets/images/products/diapers-huggies-2.jpg',
          'assets/images/products/diapers-huggies-3.jpg'
        ]
      },
      {
        _id: '4',
        id: '4',
        title: 'Электрический молокоотсос Medela Swing',
        slug: 'medela-swing-breast-pump',
        description: 'Компактный и тихий молокоотсос с двухфазной технологией сцеживания, регулируемой мощностью и памятью ритма.',
        quantity: 18,
        price: 350,
        priceAfterDiscount: 10900,
        imageCover: 'assets/images/products/молокоотсос.jpg',
        offer: 15,
        ratingsAverage: 4.6,
        ratingsQuantity: 78,
        sold: 42,
        createdAt: '2024-01-12T14:00:00.000Z',
        updatedAt: '2024-01-19T10:15:00.000Z',
        category: {
          _id: 'cat4',
          name: 'Для мам',
          slug: 'for-moms',
          image: 'assets/images/categories/for-moms.jpg'
        },
        brand: {
          _id: 'brand4',
          name: 'Medela',
          slug: 'medela',
          image: 'assets/images/brands/medela.jpg'
        },
        subcategory: [
          {
            _id: 'sub4',
            name: 'Молокоотсосы',
            slug: 'breast-pumps',
            category: 'cat4'
          }
        ],
        images: [
          'assets/images/products/breast-pump-medela-1.jpg',
          'assets/images/products/breast-pump-medela-2.jpg',
          'assets/images/products/breast-pump-medela-3.jpg'
        ]
      },
      {
        _id: '5',
        id: '5',
        title: 'Детская кроватка IKEA Sundvik',
        slug: 'ikea-sundvik-crib',
        description: 'Экологичная деревянная кроватка с регулируемым дном, 2 положениями матраса и функцией трансформации в подростковую кровать.',
        quantity: 12,
        price: 400,
        priceAfterDiscount: 18900,
        imageCover: 'assets/images/products/кроватка.jpg',
        offer: 14,
        ratingsAverage: 4.8,
        ratingsQuantity: 63,
        sold: 28,
        createdAt: '2024-01-08T11:00:00.000Z',
        updatedAt: '2024-01-21T13:40:00.000Z',
        category: {
          _id: 'cat5',
          name: 'Детская мебель',
          slug: 'kids-furniture',
          image: 'assets/images/categories/furniture.jpg'
        },
        brand: {
          _id: 'brand5',
          name: 'IKEA',
          slug: 'ikea',
          image: 'assets/images/brands/ikea.jpg'
        },
        subcategory: [
          {
            _id: 'sub5',
            name: 'Кроватки',
            slug: 'cribs',
            category: 'cat5'
          }
        ],
        images: [
          'assets/images/products/crib-ikea-1.jpg',
          'assets/images/products/crib-ikea-2.jpg',
          'assets/images/products/crib-ikea-3.jpg'
        ]
      },
      {
        _id: '6',
        id: '6',
        title: 'Радионяня Philips Avent SCD735',
        slug: 'philips-avent-baby-monitor',
        description: 'Цифровая радионяня с DECT технологией, ночным видением, температурным датчиком и возможностью подключения 2 камер.',
        quantity: 22,
        price: 323,
        priceAfterDiscount: 7490,
        imageCover: 'assets/images/products/радионяня.jpg',
        offer: 16,
        ratingsAverage: 4.7,
        ratingsQuantity: 112,
        sold: 75,
        createdAt: '2024-01-03T16:00:00.000Z',
        updatedAt: '2024-01-17T09:25:00.000Z',
        category: {
          _id: 'cat6',
          name: 'Электроника',
          slug: 'electronics',
          image: 'assets/images/categories/electronics.jpg'
        },
        brand: {
          _id: 'brand6',
          name: 'Philips Avent',
          slug: 'philips-avent',
          image: 'assets/images/brands/philips.jpg'
        },
        subcategory: [
          {
            _id: 'sub6',
            name: 'Радионяни',
            slug: 'baby-monitors',
            category: 'cat6'
          }
        ],
        images: [
          'assets/images/products/baby-monitor-philips-1.jpg',
          'assets/images/products/baby-monitor-philips-2.jpg',
          'assets/images/products/baby-monitor-philips-3.jpg'
        ]
      }
    ];
    this._productsDataService.lengthProducts.subscribe({
      next: (length) => {
        this.productLength = length;
      },
    });
  }

  displayAllProducts(): void {
    this._productsDataService.allProducts().subscribe({
      next: (response) => {
        this.allProducts = response.data;
        this.pageSize = response.metadata.limit;
        this.currentPage = response.metadata.currentPage;
        this.totalItems = response.results;
        this.getOffer(response.data);
        this.getUniqueBrandNames(this.allProducts);
      },
    });
  }

  pageChanged(event: any) {
    this._productsDataService.allProducts(event).subscribe({
      next: (response) => {
        this.allProducts = response.data;
        this.pageSize = response.metadata.limit;
        this.currentPage = response.metadata.currentPage;
        this.totalItems = response.results;
        this.getOffer(response.data);
        this.viewportScroller.scrollToPosition([0, 0]);
      },
    });
  }
  getUniqueBrandNames(allItems: Products[]): void {
    let uniqeBrand: string[] = [];
    allItems.map((item) => {
      if (!uniqeBrand.includes(item.brand.name)) {
        uniqeBrand.push(item.brand.name);
      }
    });
    this.uniqeBrands = uniqeBrand;
  }
  filterCategory(event: any): void {
    this.selectedCategoryName = event.innerHTML.toLowerCase();
    const liElements =
      this.chosesCategory.nativeElement.querySelectorAll('li a ');
    liElements.forEach((anchor: HTMLElement) => {
      this._renderer2.removeClass(anchor, 'selectActive');
    });
    this._renderer2.addClass(event, 'selectActive');
  }

  onStarClick(rating: number): void {
    this.ratingNumber = rating;
    this.addActiveForStars(rating);
  }
  addActiveForStars(rating: number) {
    const parentStar = this.allStarts.nativeElement.querySelectorAll('i');

    parentStar.forEach((star: HTMLElement, index: number, arr: Array<any>) => {
      this._renderer2.removeClass(star, 'avctiveStart');
      if (rating >= index + 1) {
        this._renderer2.addClass(star, 'avctiveStart');
      }
    });
  }
  resetAllOptions(): void {
    const liElements =
      this.chosesCategory.nativeElement.querySelectorAll('li a ');
    const defult: string = 'all';
    const defultelements =
      this.chosesCategory.nativeElement.querySelector('li a ');
    this.selectedCategoryName = 'all';
    this.selectedBrandName = defult;
    this.selectedOption = defult;
    this.sortBy = 'sort';
    this.priceRange = 45000;
    this.addActiveForStars(5);
    liElements.forEach((anchor: HTMLElement) => {
      this._renderer2.removeClass(anchor, 'selectActive');
    });
    this._renderer2.addClass(defultelements, 'selectActive');
  }
  getOffer(products: Products[]) {
    products.forEach((item) => {
      if (item.priceAfterDiscount) {
        item.offer = Math.round(
          ((item.price - item.priceAfterDiscount) / item.price) * 100
        );
      } else {
        const randomDiscount = Math.floor(Math.random() * 50) + 1;
        item.offer = randomDiscount;
      }
    });
  }
}
