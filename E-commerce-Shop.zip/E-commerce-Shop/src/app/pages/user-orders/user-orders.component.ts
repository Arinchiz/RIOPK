import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/core/cart.service';
import { Allorders } from 'src/app/interfaces/allorders';

@Component({
  selector: 'app-user-orders',
  templateUrl: './user-orders.component.html',
  styleUrls: ['./user-orders.component.css'],
})
export class UserOrdersComponent implements OnInit {
  constructor(private _cartService: CartService) {}
  _idCart: string = '';
  userId: any;
  userOrder: Allorders[] = [];
  userImage: string | null = '';
  ngOnInit(): void {
    const userData = this._cartService.decodeUserData();
    this.userId = userData.id;
    // this.displayUserOrders();
    this.userOrder = [
      {
        "shippingAddress": {
          "phone": "+7 (999) 123-45-67",
          "city": "Москва",
          "details": "ул. Пушкина, д. 10, кв. 25"
        },
        "taxPrice": 0,
        "shippingPrice": 20,
        "totalOrderPrice": 30400,
        "paymentMethodType": "card",
        "isPaid": true,
        "isDelivered": true,
        "_id": "68f3b4a5290dd3595dc5c14d",
        "user": {
          "_id": "68f3b418290dd3595dc5b245",
          "name": "Анна Иванова",
          "email": "anna@mail.ru",
          "phone": "+7 (999) 123-45-67"
        },
        "cartItems": [
          {
            "count": 1,
            "_id": "68f3b450290dd3595dc5b854",
            "product": {
              "subcategory": [
                {
                  "_id": "6407f243b575d3b90bf957ad",
                  "name": "Детские шезлонги",
                  "slug": "baby-bouncers",
                  "category": "6439d5b90049ad0b52b90049"
                }
              ],
              "ratingsQuantity": 89,
              "_id": "6428dfa0dc1175abc65ca068",
              "title": "Детский шезлонг-качалка 4moms MamaRoo",
              "imageCover": "https://ecommerce.routemisr.com/Route-Academy-products/1680394855158-cover.jpeg",
              "category": {
                "_id": "6439d5b90049ad0b52b90049",
                "name": "Детские товары",
                "slug": "baby-products",
                "image": "https://ecommerce.routemisr.com/Route-Academy-categories/1681511865181.jpeg"
              },
              "brand": {
                "_id": "64089dc924b25627a25315a9",
                "name": "4moms",
                "slug": "4moms",
                "image": "https://ecommerce.routemisr.com/Route-Academy-brands/1678286281364.png"
              },
              "ratingsAverage": 4.9,
              "id": "6428dfa0dc1175abc65ca068"
            },
            "price": 29900
          }
        ],
        "createdAt": "2024-02-15T10:30:00.000Z",
        "updatedAt": "2024-02-18T14:20:00.000Z",
        "paidAt": "2025-10-19T11:30:00.000Z",
        "id": 70510,
      },
      {
        "shippingAddress": {
          "phone": "+7 (999) 234-56-78",
          "city": "Санкт-Петербург",
          "details": "пр. Невский, д. 45, кв. 12"
        },
        "taxPrice": 0,
        "shippingPrice": 30,
        "totalOrderPrice": 188,
        "paymentMethodType": "cash",
        "isPaid": false,
        "isDelivered": false,
        "_id": "68f3b4a5290dd3595dc5c14e",
        "user": {
          "_id": "68f3b418290dd3595dc5b246",
          "name": "Мария Петрова",
          "email": "maria@mail.ru",
          "phone": "+7 (999) 234-56-78"
        },
        "cartItems": [
          {
            "count": 1,
            "_id": "68f3b450290dd3595dc5b855",
            "product": {
              "subcategory": [
                {
                  "_id": "6407f243b575d3b90bf957ae",
                  "name": "Автокресла 0+",
                  "slug": "0plus-car-seats",
                  "category": "6439d5b90049ad0b52b9004a"
                }
              ],
              "ratingsQuantity": 94,
              "_id": "6428dfa0dc1175abc65ca069",
              "title": "Автокресло Cybex Cloud Z i-Size",
              "imageCover": "assets/images/products/автокресло.jpg",
              "category": {
                "_id": "6439d5b90049ad0b52b9004a",
                "name": "Автокресла",
                "slug": "car-seats",
                "image": "https://ecommerce.routemisr.com/Route-Academy-categories/1681511865182.jpeg"
              },
              "brand": {
                "_id": "64089dc924b25627a25315aa",
                "name": "Cybex",
                "slug": "cybex",
                "image": "https://ecommerce.routemisr.com/Route-Academy-brands/1678286281365.png"
              },
              "ratingsAverage": 4.8,
              "id": "6428dfa0dc1175abc65ca069"
            },
            "price": 24500
          },
          {
            "count": 2,
            "_id": "68f3b466290dd3595dc5baa1",
            "product": {
              "subcategory": [
                {
                  "_id": "6407f1bcb575d3b90bf95798",
                  "name": "Подгузники",
                  "slug": "diapers",
                  "category": "6439d58a0049ad0b52b90040"
                }
              ],
              "ratingsQuantity": 356,
              "_id": "6428e7ecdc1175abc65ca091",
              "title": "Подгузники Huggies Elite Soft",
              "imageCover": "assets/images/products/подгузники.jpg",
              "category": {
                "_id": "6439d58a0049ad0b52b90040",
                "name": "Гигиена и уход",
                "slug": "hygiene-care",
                "image": "https://ecommerce.routemisr.com/Route-Academy-categories/1681511818072.jpeg"
              },
              "brand": {
                "_id": "64089bbe24b25627a253158c",
                "name": "Huggies",
                "slug": "huggies",
                "image": "https://ecommerce.routemisr.com/Route-Academy-brands/1678285758110.png"
              },
              "ratingsAverage": 4.7,
              "id": "6428e7ecdc1175abc65ca091"
            },
            "price": 3180
          }
        ],
        "createdAt": "2024-02-16T14:15:00.000Z",
        "updatedAt": "2024-02-16T14:15:00.000Z",
        "paidAt": "2025-10-19T11:30:00.000Z",
        "id": 70511,
      },
      {
        "shippingAddress": {
          "phone": "+7 (999) 345-67-89",
          "city": "Екатеринбург",
          "details": "ул. Ленина, д. 78, кв. 34"
        },
        "taxPrice": 0,
        "shippingPrice": 25,
        "totalOrderPrice": 26390,
        "paymentMethodType": "card",
        "isPaid": true,
        "isDelivered": false,
        "_id": "68f3b4a5290dd3595dc5c14f",
        "user": {
          "_id": "68f3b418290dd3595dc5b247",
          "name": "Елена Сидорова",
          "email": "elena@mail.ru",
          "phone": "+7 (999) 345-67-89"
        },
        "cartItems": [
          {
            "count": 1,
            "_id": "68f3b450290dd3595dc5b856",
            "product": {
              "subcategory": [
                {
                  "_id": "6407f243b575d3b90bf957af",
                  "name": "Молокоотсосы",
                  "slug": "breast-pumps",
                  "category": "6439d5b90049ad0b52b9004b"
                }
              ],
              "ratingsQuantity": 78,
              "_id": "6428dfa0dc1175abc65ca06a",
              "title": "Электрический молокоотсос Medela Swing",
              "imageCover": "https://ecommerce.routemisr.com/Route-Academy-products/1680400287656-cover.jpeg",
              "category": {
                "_id": "6439d5b90049ad0b52b9004b",
                "name": "Для мам",
                "slug": "for-moms",
                "image": "https://ecommerce.routemisr.com/Route-Academy-categories/1681511865183.jpeg"
              },
              "brand": {
                "_id": "64089dc924b25627a25315ab",
                "name": "Medela",
                "slug": "medela",
                "image": "https://ecommerce.routemisr.com/Route-Academy-brands/1678286281366.png"
              },
              "ratingsAverage": 4.6,
              "id": "6428dfa0dc1175abc65ca06a"
            },
            "price": 10900
          },
          {
            "count": 1,
            "_id": "68f3b466290dd3595dc5baa2",
            "product": {
              "subcategory": [
                {
                  "_id": "6407f1bcb575d3b90bf95799",
                  "name": "Радионяни",
                  "slug": "baby-monitors",
                  "category": "6439d58a0049ad0b52b90041"
                }
              ],
              "ratingsQuantity": 112,
              "_id": "6428e7ecdc1175abc65ca092",
              "title": "Радионяня Philips Avent SCD735",
              "imageCover": "https://ecommerce.routemisr.com/Route-Academy-products/1680402411835-cover.jpeg",
              "category": {
                "_id": "6439d58a0049ad0b52b90041",
                "name": "Электроника",
                "slug": "electronics",
                "image": "https://ecommerce.routemisr.com/Route-Academy-categories/1681511818073.jpeg"
              },
              "brand": {
                "_id": "64089bbe24b25627a253158d",
                "name": "Philips Avent",
                "slug": "philips-avent",
                "image": "https://ecommerce.routemisr.com/Route-Academy-brands/1678285758111.png"
              },
              "ratingsAverage": 4.7,
              "id": "6428e7ecdc1175abc65ca092"
            },
            "price": 7490
          },
          {
            "count": 1,
            "_id": "68f3b466290dd3595dc5baa3",
            "product": {
              "subcategory": [
                {
                  "_id": "6407f1bcb575d3b90bf9579a",
                  "name": "Кроватки",
                  "slug": "cribs",
                  "category": "6439d58a0049ad0b52b90042"
                }
              ],
              "ratingsQuantity": 63,
              "_id": "6428e7ecdc1175abc65ca093",
              "title": "Детская кроватка IKEA Sundvik",
              "imageCover": "https://ecommerce.routemisr.com/Route-Academy-products/1680402411836-cover.jpeg",
              "category": {
                "_id": "6439d58a0049ad0b52b90042",
                "name": "Детская мебель",
                "slug": "kids-furniture",
                "image": "https://ecommerce.routemisr.com/Route-Academy-categories/1681511818074.jpeg"
              },
              "brand": {
                "_id": "64089bbe24b25627a253158e",
                "name": "IKEA",
                "slug": "ikea",
                "image": "https://ecommerce.routemisr.com/Route-Academy-brands/1678285758112.png"
              },
              "ratingsAverage": 4.8,
              "id": "6428e7ecdc1175abc65ca093"
            },
            "price": 18900
          }
        ],
        "createdAt": "2024-02-17T09:45:00.000Z",
        "updatedAt": "2024-02-18T11:30:00.000Z",
        "paidAt": "2025-10-19T11:30:00.000Z",
        "id": 70512,
      }
    ]
  }
  displayUserOrders() {
    this._cartService.getUserOrders(this.userId).subscribe({
      next: (response) => {
        this.userOrder = response;
        this._cartService.orderNumber.next(response.length);
      },
      error: (err) => {
        console.log(err);
      },
    });
  }
}
