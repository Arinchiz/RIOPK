import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/core/cart.service';
import { Allorders } from 'src/app/interfaces/allorders';

@Component({
  selector: 'app-user-orders',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
})
export class UsersComponent implements OnInit {
  constructor(private _cartService: CartService) {}
  ngOnInit(): void {
  }

  p: number = 1;
  searchTerm: string = '';
  roleFilter: string = '';
  statusFilter: string = '';

  // Тестовые данные
  users = [
    {
      id: 1,
      name: 'Иван',
      surname: 'Петров',
      email: 'ivan@mail.ru',
      phone: '+7 (999) 123-45-67',
      role: 'user',
      isBlocked: false,
      registrationDate: new Date('2023-05-15'),
      ordersCount: 12
    },
    {
      id: 2,
      name: 'Мария',
      surname: 'Сидорова',
      email: 'maria@mail.ru',
      phone: '+7 (999) 234-56-78',
      role: 'seller',
      isBlocked: false,
      registrationDate: new Date('2023-08-22'),
      ordersCount: 45
    },
    {
      id: 3,
      name: 'Алексей',
      surname: 'Козлов',
      email: 'alex@mail.ru',
      phone: '+7 (999) 345-67-89',
      role: 'admin',
      isBlocked: false,
      registrationDate: new Date('2023-01-10'),
      ordersCount: 8
    },
    {
      id: 4,
      name: 'Елена',
      surname: 'Новикова',
      email: 'elena@mail.ru',
      phone: '+7 (999) 456-78-90',
      role: 'user',
      isBlocked: true,
      registrationDate: new Date('2023-11-05'),
      ordersCount: 3
    },
    {
      id: 5,
      name: 'Дмитрий',
      surname: 'Волков',
      email: 'dmitry@mail.ru',
      phone: '+7 (999) 567-89-01',
      role: 'seller',
      isBlocked: false,
      registrationDate: new Date('2023-03-18'),
      ordersCount: 67
    }
  ];

  get filteredUsers() {
    return this.users.filter(user => {
      const matchesSearch = !this.searchTerm ||
        user.name.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
        user.surname.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(this.searchTerm.toLowerCase());

      const matchesRole = !this.roleFilter || user.role === this.roleFilter;

      const matchesStatus = !this.statusFilter ||
        (this.statusFilter === 'active' && !user.isBlocked) ||
        (this.statusFilter === 'blocked' && user.isBlocked);

      return matchesSearch && matchesRole && matchesStatus;
    });
  }

  getActiveUsersCount(): number {
    return this.users.filter(user => !user.isBlocked).length;
  }

  getSellersCount(): number {
    return this.users.filter(user => user.role === 'seller').length;
  }

  getBlockedUsersCount(): number {
    return this.users.filter(user => user.isBlocked).length;
  }

  resetFilters(): void {
    this.searchTerm = '';
    this.roleFilter = '';
    this.statusFilter = '';
    this.p = 1;
  }

  changeUserRole(userId: number, event: any): void {
    const newRole = event.target.value;
    const user = this.users.find(u => u.id === userId);
    if (user) {
      user.role = newRole;
      // Здесь можно добавить вызов API для сохранения изменений
      console.log(`Роль пользователя ${userId} изменена на ${newRole}`);
    }
  }

  toggleBlockUser(userId: number, block: boolean): void {
    const user = this.users.find(u => u.id === userId);
    if (user) {
      user.isBlocked = block;
      // Здесь можно добавить вызов API для сохранения изменений
      console.log(`Пользователь ${userId} ${block ? 'заблокирован' : 'разблокирован'}`);
    }
  }

  viewUserDetails(userId: number): void {
    // Навигация к детальной странице пользователя
    console.log(`Просмотр деталей пользователя ${userId}`);
  }

  viewUserOrders(userId: number): void {
    // Навигация к истории заказов пользователя
    console.log(`Просмотр заказов пользователя ${userId}`);
  }
}
