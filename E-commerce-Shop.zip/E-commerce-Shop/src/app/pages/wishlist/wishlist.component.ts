import { Component, OnInit } from '@angular/core';
import { WishlistService } from 'src/app/core/wishlist.service';
import { Products } from 'src/app/interfaces/products';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css'],
})
export class WishlistComponent implements OnInit {
  constructor(private _wishlistService: WishlistService) {}
  wishListProducts: Products[] = [];
  isLoding: boolean = false;
  ngOnInit(): void {
    // this.dsiplayWishList();
    this.wishListProducts = [
      {
        _id: '2',
        id: '2',
        title: 'Автокресло Cybex Cloud Z i-Size',
        slug: 'cybex-cloud-z-isize',
        description: 'Безопасное автокресло группы 0+ с поворотной системой, защитой от боковых ударов и регулируемым подголовником.',
        quantity: 25,
        price: 150,
        priceAfterDiscount: 24500,
        imageCover: 'assets/images/products/автокресло.jpg',
        offer: 12,
        ratingsAverage: 4.8,
        ratingsQuantity: 94,
        sold: 67,
        createdAt: '2024-01-10T09:00:00.000Z',
        updatedAt: '2024-01-18T16:45:00.000Z',
        category: {
          _id: 'cat2',
          name: 'Автокресла',
          slug: 'car-seats',
          image: 'assets/images/categories/car-seats.jpg'
        },
        brand: {
          _id: 'brand2',
          name: 'Cybex',
          slug: 'cybex',
          image: 'assets/images/brands/cybex.jpg'
        },
        subcategory: [
          {
            _id: 'sub2',
            name: 'Автокресла 0+',
            slug: '0plus-car-seats',
            category: 'cat2'
          }
        ],
        images: [
          'assets/images/products/car-seat-cybex-1.jpg',
          'assets/images/products/car-seat-cybex-2.jpg',
          'assets/images/products/car-seat-cybex-3.jpg'
        ]
      },
      {
        _id: '5',
        id: '5',
        title: 'Детская кроватка IKEA Sundvik',
        slug: 'ikea-sundvik-crib',
        description: 'Экологичная деревянная кроватка с регулируемым дном, 2 положениями матраса и функцией трансформации в подростковую кровать.',
        quantity: 12,
        price: 400,
        priceAfterDiscount: 18900,
        imageCover: 'assets/images/products/кроватка.jpg',
        offer: 14,
        ratingsAverage: 4.8,
        ratingsQuantity: 63,
        sold: 28,
        createdAt: '2024-01-08T11:00:00.000Z',
        updatedAt: '2024-01-21T13:40:00.000Z',
        category: {
          _id: 'cat5',
          name: 'Детская мебель',
          slug: 'kids-furniture',
          image: 'assets/images/categories/furniture.jpg'
        },
        brand: {
          _id: 'brand5',
          name: 'IKEA',
          slug: 'ikea',
          image: 'assets/images/brands/ikea.jpg'
        },
        subcategory: [
          {
            _id: 'sub5',
            name: 'Кроватки',
            slug: 'cribs',
            category: 'cat5'
          }
        ],
        images: [
          'assets/images/products/crib-ikea-1.jpg',
          'assets/images/products/crib-ikea-2.jpg',
          'assets/images/products/crib-ikea-3.jpg'
        ]
      },
    ];
  }

  dsiplayWishList() {
    this._wishlistService.getWishlistItem().subscribe({
      next: (response) => {
        this.wishListProducts = response.data;
        this.getOffer(this.wishListProducts);
      },
    });
  }

  getOffer(products: Products[]) {
    products.forEach((item) => {
      if (item.priceAfterDiscount) {
        item.offer = Math.round(
          ((item.price - item.priceAfterDiscount) / item.price) * 100
        );
      } else {
        const randomDiscount = Math.floor(Math.random() * 50) + 1;
        item.offer = randomDiscount;
      }
    });
  }
}
