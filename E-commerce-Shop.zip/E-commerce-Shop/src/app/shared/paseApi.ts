export const baseUrl = 'https://ecommerce.routemisr.com';
